package com.example.lourdofficiel;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class MainActivity4 extends AppCompatActivity {

public RecyclerView recyclerView;
public TextView tv40, tv41, tv42, tv43, tv44, tv45, tv46;
public Button but30;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        but30 = findViewById(R.id.but30);

        tv40 = findViewById(R.id.tv40);
        tv41 = findViewById(R.id.tv41);
        tv42 = findViewById(R.id.tv42);
        tv43 = findViewById(R.id.tv43);
        tv44 = findViewById(R.id.tv44);
        tv45 = findViewById(R.id.tv45);

        tv40.setText("Survetement noir");
        tv41.setText(" Debardeur blanc");
        tv42.setText(" Short vert fripe");
        tv43.setText(" Cargo vert ");
        tv44.setText(" Pull jaune");
        tv45.setText(" T-shirt noir audi");



        but30.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity4.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}