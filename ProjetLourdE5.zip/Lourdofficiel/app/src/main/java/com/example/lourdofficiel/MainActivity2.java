package com.example.lourdofficiel;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    private TextView tv10, tv3, tv5, tv6;
    public Button outbut1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        tv10 = findViewById(R.id.tv10);
        tv3 = findViewById(R.id.tv3);
        tv5 = findViewById(R.id.tv5);
        tv6 = findViewById(R.id.tv6);


        outbut1 = findViewById(R.id.outbut1);

        tv3.setText("Mon dressing");

        outbut1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}